<?php
class Ruta
{

    public static function ctrRuta()
    {
        return "http://localhost/mecanica/";
    }

}

<?php

    require_once "conexion.php";
    
    class ModeloUsuarios
    {
    

        /*=============================================
        MOSTRAR EL TOTAL DE VENTAS
        =============================================*/
    
        public static function mdlMostrarTotalUsuarios($tabla)
        {
    
            $stmt = Conexion::conectar()->prepare("SELECT * FROM $tabla WHERE FK_ROL = 1 ORDER BY ID_USUARIO DESC");
    
            $stmt->execute();
    
            return $stmt->fetchAll();
    
            $stmt->close();
    
            $stmt = null;
    
        }

            /*=============================================
            ELIMINAR USUARIO
            =============================================*/


        public static function mdlEliminarPaciente($tabla, $id_usuario)
        {
            try {
                $stmt = Conexion::conectar()->prepare("DELETE FROM $tabla WHERE ID_USUARIO = :id_usuario");
                $stmt->bindParam(":id_usuario", $id_usuario, PDO::PARAM_INT);
    
                if ($stmt->execute()) {
                    return "ok";
                } else {
                    return "error";
                }
            } catch (PDOException $e) {
                return "error";
            }
        }

    }


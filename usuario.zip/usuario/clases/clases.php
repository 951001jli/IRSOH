<?php 

#Class es una plantilla que usamos para crear objetos.

class Principal{
    public $var = "Hola mundo";
    public function inicio()
    {
        echo $this->var;

    }
}
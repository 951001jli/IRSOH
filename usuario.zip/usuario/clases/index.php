<?php 
require_once "clases.php";
{
$plantilla =new Principal();
$plantilla->inicio();

}
<?php 

class Metodo
{
    static public function mostrar($nombre)
    {
        echo "El nombre es: " . $nombre;
    }
}

$nombre = "ever";
$resultado=Metodo::mostrar($nombre);

<?php


    require_once "controlador/administrador.controlador.php";
    require_once "controlador/usuario.controlador.php";
    require_once "controlador/plantilla.controlador.php";
    require_once "controlador/perfil.controlador.php";


    require_once "modelos/administrador.modelo.php";
    require_once "modelos/usuario.modelo.php";
    require_once "modelos/perfil.modelo.php";

    require_once "modelos/rutas.php";

    $plantilla = new ControladorPlantilla();
    $plantilla->ctrPlantilla();

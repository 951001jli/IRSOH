
<div class="content" style="width: 100%; max-width: 1200px; margin: 20px auto;">
  <div class="animated fadeIn">
    <div class="row">

      <div class="col-md-4">
        <div class="card" style="margin-bottom: 10px; border radius:8px">
        <img src="" alt="avatar" class="rounded" style="width: 100%;">
          <div class="card-body">
            <h4 class="card-title mb-3" style="text-align: center;"><?php echo $usuario["nombre_completo"];?></h4>
            <p class="card-text" style="text-align: center;"><?php echo $usuario['correo']; ?></p>
            <p class="card-text" style="text-align: center;"><?php echo $usuario['usuario']; ?></p>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>      
<!-- Left Panel -->
<aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="inicio_usuario"><i class="menu-icon fa fa-home"></i>Inicio </a>
                    </li>
                    
                    
                    <li class="">
                        <a href="" > <i class="menu-icon fa fa-calendar-o" aria-hidden="true"></i>Galeria</a>
                    </li>

                    <li class="">
                        <a href="" > <i class="menu-icon fa fa-user" aria-hidden="true"></i>Mi perfil</a>
                    </li>

                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside>

<?php

    $listarPerfil = new ControladorPerfil();
    $lista = $listarPerfil->ctrMostrarPerfil($_SESSION["id"]);



?>


<section style="background-color: #eee;">
  <div class="container py-5">
    <div class="row">
      <div class="col">
        <nav aria-label="breadcrumb" class="bg-light rounded-3 p-3 mb-4">
          <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item"><a href="inicio">Inicio</a></li>
            <li class="breadcrumb-item"><a href="perfil">Perfil</a></li>
          </ol>
        </nav>
      </div>
    </div>

<div class="row">
      <div class="col-lg-4">
        <div class="card mb-4">
          <div class="card-body text-center">
          <?php if(isset($lista["FOTO_PERFIL"])): ?>
              <img src="<?php echo $lista["FOTO_PERFIL"]; ?>"
                alt="Foto de perfil" class="rounded-circle img-fluid" style="width: 150px;">
            <?php else: ?>
              <img src="views/img/perfil/default/anonymous.png"
                alt="Foto de perfil estática" class="rounded-circle img-fluid" style="width: 150px;">
            <?php endif; ?>
           
            <div class="btn-group">
            <button class="btn btn-warning btnEditarPerfil" data-toggle="modal" data-target="#modalEditarPerfil"><i class="fa fa-pencil-square-o"></i></button>
            
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-8">
        <div class="card mb-4">
          <div class="card-body">
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Nombre</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0"><?php echo $lista["NOMBRE_USUARIO"] . " " . $lista["APELLIDOS_USUARIO"]?></p>
              </div>
            </div>
            
            <hr>
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Correo</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0"><?php echo $lista["CORREO"]; ?></p>
              </div>
            </div>
            <hr>
            
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Telefono</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0"><?php echo $lista["TELEFONO"]; ?></p>
              </div>
            </div>
           
            <hr>
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Ocupacion</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0"><?php echo $lista["OCUPACION"]; ?></p>
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Genero</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0"><?php echo $lista["GENERO"]; ?></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>



<div class="modal fade" id="modalEditarPerfil" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                              <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Editar perfil</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                  <span aria-hidden="true">&times;</span>
                                                </button>
                                              </div>
                                              <div class="modal-body">
                                              <form method="post" enctype="multipart/form-data">
                                              <input type="hidden" id="id_perfil" name="id_perfil" value="<?php echo $_SESSION['id']; ?>">
                                            <div class="input-group mb-3">
                                              <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">Nombre</span>
                                              </div>
                                              <input type="text" class="form-control" placeholder="Nombre" id="nombre" name="nombre" aria-label="Username" aria-describedby="basic-addon1" id="NOMBRE" value="<?php echo $lista["NOMBRE_USUARIO"]; ?>">
                                            </div>


                                            <div class="input-group mb-3">
                                              <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">Apellidos</span>
                                              </div>
                                              <input type="text" class="form-control" id="apellidos" name="apellidos" placeholder="Descripción" aria-label="Username" aria-describedby="basic-addon1" value="<?php echo $lista["APELLIDOS_USUARIO"]; ?>">
                                            </div>

                                            <div class="input-group mb-3">
                                              <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">Correo eléctronico</span>
                                              </div>
                                              <input type="text" class="form-control" id="correo" name="correo" placeholder="Descripción" aria-label="Username" aria-describedby="basic-addon1" value="<?php echo $lista["CORREO"]; ?>">
                                            </div>

                                            <div class="input-group mb-3">
                                              <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">Telefono</span>
                                              </div>
                                              <input type="text" class="form-control" id="telefono" name="telefono" placeholder="Teléfono" aria-label="Username" aria-describedby="basic-addon1" value="<?php echo $lista["TELEFONO"]; ?>">
                                            </div>

                                            <div class="input-group mb-3">
                                              <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">Ocupación</span>
                                              </div>
                                              <input type="text" class="form-control" id="ocupacion" name="ocupacion" placeholder="Ocupación" aria-label="Username" aria-describedby="basic-addon1" value="<?php echo $lista["OCUPACION"]; ?>">
                                            </div>


                                            <div class="input-group mb-3">
                                              <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">Género</span>
                                              </div>
                                              <input type="text" class="form-control" name="genero" id="genero" aria-describedby="basic-addon3" value="<?php echo $lista["GENERO"]; ?>">
                                            </div>

                                            <div class="input-group mb-3">
                                            <div class="input-group-prepend">
                                              <span class="input-group-text">Imagen</span>
                                            </div>
                                            <div class="custom-file">
                                              <input type="file" class="custom-file-input foto" id="foto" name="foto" onchange="actualizarNombreArchivo(this)">
                                              <label class="custom-file-label" for="foto">Elige archivo</label>
                                            </div>

                                            <input type="hidden" class="antiguaFoto">
                                          </div>
                                          <p class="help-block">Tamaño recomendado 400px * 450px <br> Peso máximo de la foto 2MB</p>

                                          <img src="<?php echo $lista['FOTO_PERFIL']; ?>" class="img-thumbnail previsualizar" width="200px">

                                          <script>
                                            function actualizarNombreArchivo(input) {
                                              var nombreArchivo = input.files[0].name;
                                              var label = input.nextElementSibling; // Obtener el elemento de la etiqueta siguiente

                                              // Actualizar el texto de la etiqueta con el nombre del archivo
                                              label.innerHTML = nombreArchivo;
                                            }
                                          </script>
                                              <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                                                <input type="submit" class="btn btn-primary" value="Guardar Cambios" name="editar-perfil">
                                              </div>
                                                </form>
                                              </div>
                                              
                                            </div>
                                          </div>
                                        </div>



<?php
if(isset($_POST['editar-perfil'])) { 
  $editarPerfil = new ControladorPerfil();
  $editarPerfil->ctrEditarPerfil(
    $_POST['id_perfil'],
    $_POST['nombre'],
    $_POST['apellidos'],
    $_POST['correo'],
    $_POST['telefono'],
    $_POST['ocupacion'],
    $_POST['genero'],
    $_FILES['foto']
  );
}

?>


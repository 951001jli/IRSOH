<?php

    if(isset($_GET['id_usuario'])) {
        $id_usuario = $_GET['id_usuario'];
        $eliminar_paciente = new ControladorUsuarios();
        $eliminar = $eliminar_paciente->ctrEliminarPaciente($id_usuario);
    }

    if(isset($_GET['id_horario'])) {
        $id_horario = $_GET['id_horario'];
        $eliminar_horario = new ControladorHorario();
        $eliminar = $eliminar_horario->ctrEliminarHorario($id_horario);
    }

    if(isset($_GET['id_tipo_cita'])) {
        $id_tipo_cita = $_GET['id_tipo_cita'];
        $eliminar_tipo_cita = new ControladorTiCita();
        $eliminar = $eliminar_tipo_cita->ctrEliminarTipCita($id_tipo_cita);
    }
    if(isset($_GET['id_cita'])) {
        $id_cita = $_GET['id_cita'];
        $listarCitasCitas = new ControladorCita();
        $lista = $listarCitasCitas->ctrRechazarCita($id_cita);
                                            
    } else if(isset($_GET['id_cita_aceptar'])) {
        $id_cita_aceptar = $_GET['id_cita_aceptar'];
        $listarCitasCitas = new ControladorCita();
        $lista = $listarCitasCitas->ctrAceptarCita($id_cita_aceptar);
                                            
    }
    else {
        echo "<p style='color: red;'> No se elimino correctamente </p>";
    }
<?php

class ControladorUsuarios
{


    /*=============================================
    MOSTRAR TOTAL PRODUCTOS
    =============================================*/

    public static function ctrMostrarTotalUsuarios()
    {

        $tabla = "tb_usuarios";

        $respuesta = ModeloUsuarios::mdlMostrarTotalUsuarios($tabla);

        return $respuesta;

    }

    public static function ctrEliminarPaciente($id_usuario)
    {
        $tabla = "tb_usuarios";
        $respuesta = ModeloUsuarios::mdlEliminarPaciente($tabla, $id_usuario);
        if ($respuesta == "ok") {
            echo '<script>
                    window.location.href = "pas_med";
                </script>';
        }
    }
}